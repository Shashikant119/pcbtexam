$(document).ready(function() {
    $('#toggle_btn').click(function() {
        $('.toggle-right').toggleClass('toggle_slide');
    });
});